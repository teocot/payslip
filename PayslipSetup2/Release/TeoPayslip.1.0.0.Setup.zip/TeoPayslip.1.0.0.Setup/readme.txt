Hi,

To install the Payslip demo program, please run the setup.exe

You have to accept the installation and provide admin credentials.
When you run the test harness from within the app, you have to allow nunit.exe to run.

Thank you for downloading the program.
Teodor Cotruta, 11.01.2016